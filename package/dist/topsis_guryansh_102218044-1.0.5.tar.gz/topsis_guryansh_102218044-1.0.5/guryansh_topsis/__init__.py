# Version of Module
from .topsis import topsis
__version__ = 1.1
